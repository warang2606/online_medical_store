import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-additem',
  templateUrl: './admin-additem.component.html',
  styleUrls: ['./admin-additem.component.css']
})
export class AdminAdditemComponent {

}
