import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-listitem',
  templateUrl: './admin-listitem.component.html',
  styleUrls: ['./admin-listitem.component.css']
})
export class AdminListitemComponent {

}
